package com.autumn.allocations.model;

public class Org {

}
