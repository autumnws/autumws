package com.autumn.allocations.model;

public class Request {

}
