package com.autumn.employees.model;

import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


public class Allocation {
	
	private Workspace workspace;
}
