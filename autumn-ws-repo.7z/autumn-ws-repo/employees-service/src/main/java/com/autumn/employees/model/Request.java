package com.autumn.employees.model;

public class Request {

}
